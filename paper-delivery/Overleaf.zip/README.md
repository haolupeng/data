# UAKAnD1 -- user-supplied journal template edition

## Upload to Overleaf

1. Create a new project using Upload Project and choose this ZIP.
2. Set `main.tex` as the main document.
3. Use pdfLaTeX (TeX Live 2025 or the latest available version) and recompile.

All manuscript text and tables are in `main.tex`, following the single-manuscript-file convention in the uploaded template. `references.bib`, figure PDFs, `sn-jnl.cls`, and `sn-mathphys-num.bst` are included. No external file downloads or Python execution are required for compilation. `manuscript.pdf` is the compiled preview.

## Template provenance

The class and bibliography style are copied byte-for-byte from the user-uploaded `沙特.zip`. Class options match its manuscript: `pdflatex,sn-mathphys-num`. This edition replaces the previous article fallback with the supplied Springer Nature class. No independent claim is made about the journal's current policies beyond the supplied template. The sample manuscript's authors, funding, scientific prose, images, and results are not reused.

## Content

This is the English UAKAnD1 manuscript with equations, method flow diagram, algorithm description, four full experimental tables, a significance-count summary, a best-mean-count figure, and bibliography. No ablation experiments have been incorporated. Data numbers and significance annotations come exclusively from the user-designated result-table DOCX. `data/source_table_transcription.csv` retains all 1068 source-cell strings; `data/audit.json` records its source hash and summary counts.

Means and standard deviations are formatted on two lines to fit the template's text width. Boldface marks best reported means, including ties. No numerical values or significance outcomes are changed during typesetting.

## Author details still required

Replace the author-name, email, affiliation, funding, contributions, and competing-interest placeholders with confirmed information. The experimental population size, actual parameter overrides, seeds, exact experiment-producing code revision, software versions, and hardware still require author verification, as stated in the manuscript. Template adaptation does not resolve these evidence gaps or guarantee acceptance.

## Local build

Run `latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex`, or run pdfLaTeX, BibTeX, then pdfLaTeX twice. This edition was compiled and its first page and table pagination were visually checked.

## Color-preserving revision

All original cell fills, first-run font colors and bold settings are read directly from the designated Word document, including green best values, yellow second-best distinct values, blue headers and gray identifier columns. All four table notes and the final data note are included. Formatting is not inferred from rounded numbers. The source-format audit is in data/source_format_audit.json.
